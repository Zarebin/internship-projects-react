import React from 'zarkit/react';
import ReactDOM from 'zarkit/react-dom';
import App from './App';
import "./style.scss";

ReactDOM.render(

      <App />,

  document.getElementById('root')
);

